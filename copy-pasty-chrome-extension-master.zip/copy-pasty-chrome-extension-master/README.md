# copy-pasty-chrome-extension
A chrome extensions to boost the process of copy-paste of text on a web browser
![alt text](https://www.cyclonis.com/images/2018/03/use-cyclonis-password-manager-google-chrome-extension.jpg)
- [Chrome Extensions overview](https://developer.chrome.com/extensions)

## Branch feature
- Added copy text feature from content script
- Sending message to background in global script
